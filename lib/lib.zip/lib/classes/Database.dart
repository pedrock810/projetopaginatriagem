import 'package:http/http.dart' as http;
import 'dart:convert';
import 'User.dart';

class DatabaseConnection {
  final String baseUrl =
      'http://10.0.2.2:3000'; // Coloque a URL do seu servidor Node.js

  Future<void> sendDataToServer(Map<String, dynamic> data) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/data'),
      headers: <String, String>{
        'Content-Type': 'application/json',
      },
      body: jsonEncode(data),
    );

    if (response.statusCode == 200) {
      print('Resposta do servidor: ${response.body}');
    } else {
      throw Exception('Falha ao enviar dados para o servidor');
    }
  }

  Future<void> insertUser(Map<String, dynamic> userData) async {
    final url = Uri.parse('$baseUrl/api/insertUser');

    try {
      final response = await http.post(
        url,
        headers: <String, String>{
          'Content-Type': 'application/json',
        },
        body: jsonEncode(userData),
      );

      if (response.statusCode == 200) {
        print('Usuário inserido com sucesso');
      } else {
        print('Erro ao inserir usuário. Status Code: ${response.statusCode}');
        // Se desejar, você pode tratar a resposta do servidor aqui
      }
    } catch (e) {
      print('Erro de conexão: $e');
      // Lidar com erros de conexão
    }
  }

  Future<bool> verificarEmailExistente(String email) async {
    final url = Uri.parse('$baseUrl/api/verificarEmail?email=$email');

    try {
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        final bool emailExiste = data['existe'];
        return emailExiste;
      } else {
        throw Exception('Erro ao verificar e-mail');
      }
    } catch (e) {
      print('Erro de conexão: $e');
      return false; // Tratamento de erro, retorne false por padrão
    }
  }

  Future<Map<String, dynamic>> verificarLogin(
      String email, String senha) async {
    final url = Uri.parse('$baseUrl/api/verificarLogin');
    final Map<String, String> body = {'email': email, 'senha': senha};

    try {
      final response = await http.post(
        url,
        headers: <String, String>{
          'Content-Type': 'application/json',
        },
        body: jsonEncode(body),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        return data;
      } else {
        throw Exception('Erro ao verificar login');
      }
    } catch (e) {
      print('Erro de conexão: $e');
      return {
        'correto': false
      }; // Tratamento de erro, login incorreto por padrão
    }
  }

  Future<List<Map<String, dynamic>>> listarPacientes(int id) async {
    final url = Uri.parse('$baseUrl/api/listarPacientes?id=$id');

    try {
      final response = await http.get(
        url,
        headers: <String, String>{
          'Content-Type': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        final List<Map<String, dynamic>> patientList =
        List<Map<String, dynamic>>.from(data);
        return patientList;
      } else {
        throw Exception('Erro ao listar pacientes - Status Code: ${response.statusCode}');
      }
    } catch (e) {
      print('Erro ao chamar listarPacientes: $e');
      return [];
    }
  }


// Enviar paciente para a base de dados
  Future<void> salvarPacienteNoDB({
    required String novoNome,
    required String novoSobrenome,
    required String novoUtente,
    required String novoGenero,
    required String novaIdade,
    required String novoPeso,
    required String novaAltura,
    required String novoContacto,
    required String novoDiagnotico,
  }) async {
    final url = Uri.parse('$baseUrl/salvarPacienteDB');

    final Map<String, dynamic> dadosPaciente = {
      'nome': novoNome,
      'sobrenome': novoSobrenome,
      'utente': novoUtente,
      'genero': novoGenero,
      'idade': novaIdade,
      'peso': novoPeso,
      'altura': novaAltura,
      'contacto': novoContacto,
      'diagnostico': novoDiagnotico,
      'idMedico': User.id
    };

    try {
      final response = await http.post(
        url,
        body: jsonEncode(dadosPaciente),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        print('Paciente salvo com sucesso!');
      } else {
        print('Erro ao salvar paciente: ${response.statusCode}');
      }
    } catch (e) {
      print('Erro de conexão: $e');
    }
  }
}
